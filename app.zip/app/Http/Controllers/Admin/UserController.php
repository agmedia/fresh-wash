<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Inertia\Inertia;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::query()
            ->when($request->get('search'), function ($q, $search) {
                $q->where(function ($q) use ($search) {
                    $q->where('first_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();
        
        return Inertia::render('admin/users/Index', [
            'users'   => $users,
            'filters' => [
                'search' => $request->get('search'),
            ],
        ]);
    }
    
    public function show(User $user)
    {
        return Inertia::render('admin/users/Show', [
            'user' => $user,
        ]);
    }
    
    public function edit(User $user)
    {
        return Inertia::render('admin/users/Edit', [
            'user' => $user->only([
                'id',
                'first_name',
                'last_name',
                'email',
                'address_line1',
                'address_line2',
                'postal_code',
                'city',
                'country_code',
                'phone',
                'whatsapp_opt_in',
            ]),
        ]);
    }
    
    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'first_name'      => ['nullable', 'string', 'max:100'],
            'last_name'       => ['nullable', 'string', 'max:100'],
            'email'           => ['required', 'email', 'max:255', 'unique:users,email,' . $user->id],
            'address_line1'   => ['nullable', 'string', 'max:255'],
            'address_line2'   => ['nullable', 'string', 'max:255'],
            'postal_code'     => ['nullable', 'string', 'max:20'],
            'city'            => ['nullable', 'string', 'max:100'],
            'country_code'    => ['nullable', 'string', 'size:2'],
            'phone'           => ['nullable', 'string', 'max:50'],
            'whatsapp_opt_in' => ['nullable', 'boolean'],
        ]);
        
        $data['whatsapp_opt_in'] = (bool) ($data['whatsapp_opt_in'] ?? false);
        
        $user->update($data);
        
        return redirect()
            ->route('admin.users.edit', $user)
            ->with('success', 'Korisnik je uspješno ažuriran.');
    }
}